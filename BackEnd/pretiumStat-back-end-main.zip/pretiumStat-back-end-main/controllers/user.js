
exports.initUserController = (db) => {
    let controller = {}
    controller.loginUser = (req, res, next) => {
        if(!req.query.username){
            res.status(400).send(['No username proveded.'])
            return
        }
        let sql = `SELECT * FROM users WHERE username = '${req.query.username}'`
        db.query(sql,(err, result) => {
            if (err) {
                next(res.status(500))
            }
            if(result.length == 0){
                res.status(400).send(['There no profile with this username.'])
                return;
            }
            if(result[0].password != req.query.password&&(req.query.password)){
                res.status(400).send(['Password does not match.'])
                return;
            }
            res.send({message:'User logged in.',successful:true})
        })
    }
    controller.registerUser = (req, res, next) => {
        
        let user = {
            username: req.body.username,
            password: req.body.password
        }
        let sql = 'INSERT INTO users SET ?'
        db.query(sql, user, (err, result) => {
            if (err) {
                if(err.sqlMessage.includes('Duplicate entry')){
                    res.status(409).send(['This username is already in use.'])
                    return;
                    }else{
                    next(res.status(500))
                    return;
                }
            }else{
                res.status(200).send(['Successfully registered.'])
            }
        })

        
    }
    return controller
}
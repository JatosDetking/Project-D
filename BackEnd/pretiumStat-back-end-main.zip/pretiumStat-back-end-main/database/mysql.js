const mysql = require('mysql')
let prod = false;
exports.prod = prod;
exports.initDB = () => {
    let db
    if (prod) {
        db = mysql.createConnection({
            host: 'localhost',
            port: 3306,
            user: 'plolkine_pretium_stat',
            password: '123123qweqwe',
            database: 'plolkine_pretium_stat'
        })
    } else {
        db = mysql.createConnection({
            host: 'localhost',
            port: 3306,
            user: 'root',
            password: '',
            database: 'nodemysql'
        })
    }


    db.connect((err) => {
        if (err) throw err
        console.log("MySQL Connected...");
    })

    return db
}
const express = require('express')
const errorController = require('./controllers/error');
const userRoutes = require('./routers/user');
const suggestionsRoutes = require('./routers/suggestions');
const sqlDB = require('./database/mysql');
const { initGroupsController } = require('./controllers/groups');
const { initGroupsRouter } = require('./routers/groups');

const db = sqlDB.initDB()
const prod = sqlDB.prod
const app = express();
const port = 3000

app.use(express.json());
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Autherization');
    next();
})

// creade db 
app.get('/createdb', (req, res) => {
    let sql = 'CREATE DATABASE nodemysql';
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['database created ...'])
    })
})

// create table
app.get('/createpoststable', (req, res) => {
    let sql = `CREATE TABLE posts(id int AUTO_INCREMENT, title VARCHAR(255), body VARCHAR(255), PRIMARY KEY(id))`;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Posts table created.'])
    })
})

app.get('/createuserstable', (req, res) => {
    let sql = `CREATE TABLE users(username VARCHAR(255), password VARCHAR(255), PRIMARY KEY(username))`;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Users table created.'])
    })
})

app.get('/creategroupstable', (req, res) => {
    let sql = `CREATE TABLE groups(id int AUTO_INCREMENT, name VARCHAR(255), users VARCHAR(255), PRIMARY KEY(id))`;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Groups table created.'])
    })
})

app.get('/create-suggestions-table', (req, res) => {
    let sql = `CREATE TABLE suggestions(id int AUTO_INCREMENT, type VARCHAR(255), vals TEXT, PRIMARY KEY(id))`;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Suggestions table created.'])
    })
})

app.get('/create-suggestions-table1', (req, res) => {
    let post = {
        type: 'locations',
        vals: JSON.stringify([])
    }
    let sql = 'INSERT INTO suggestions SET ?'
    let query = db.query(sql, post, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Created locations row.'])
    })
})

app.get('/create-suggestions-table2', (req, res) => {
    let post = {
        type: 'tags',
        vals: JSON.stringify([])
    }
    let sql = 'INSERT INTO suggestions SET ?'
    let query = db.query(sql, post, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Created tags row.'])
    })
})

// insert post 1

app.get('/addpost1', (req, res) => {
    let post = {
        title: 'Title',
        body: 'asdasd'
    }
    let sql = 'INSERT INTO posts SET ?'
    let query = db.query(sql, post, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.send(['Posted to posts.'])
    })
})

app.get('/drop-table', (req, res) => {
    let table_name = req.query.table_name
    let sql = `DROP TABLE ${table_name}`
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send(['Something went wrong with table drop.' + table_name])
            throw err
        } else {
            console.log(`${table_name} table was droped`);
            res.status(200).send(['Group table "' + table_name + '" was deleted successfully.']);
            return;
        }
    })
})

// select posts
app.get('/getposts', (req, res) => {
    let sql = 'SELECT * FROM posts'
    let query = db.query(sql, (err, results) => {
        if (err) throw err;
        console.log(results);
        res.send(['Posts fetched.'])
    })
})

// select post
app.get('/getpost/:id', (req, res) => {
    let sql = `SELECT * FROM posts WHERE id = ${req.params.id}`
    let query = db.query(sql, (err, results) => {
        if (err) throw err;
        console.log(results);
        res.send(['Post fetched.'])
    })
})

// update post
app.get('/updatepost/:id', (req, res) => {
    let newtitle = 'Updated Title';
    let sql = `UPDATE posts SET title = '${newtitle}' WHERE id = ${req.params.id}`
    let query = db.query(sql, (err, results) => {
        if (err) throw err;
        console.log(results);
        res.send(['Post updated.'])
    })
})

// delete post
app.get('/deletepost/:id', (req, res) => {
    let sql = `DELETE FROM posts WHERE id = ${req.params.id}`
    let query = db.query(sql, (err, results) => {
        if (err) throw err;
        console.log(results);
        res.send(['Post deleted.'])
    })
})

app.use('/user', userRoutes.initUserRouter(db));
app.use('/suggestion', suggestionsRoutes.initSuggestionRouter(db));
app.use('/groups', initGroupsRouter(db));

app.use(errorController.get404);

app.use(errorController.get500);

if(prod){
    app.listen()
}else{
    app.listen(`${port}`, () => {
        console.log(`Server listening on port ${port}`);
    })
}
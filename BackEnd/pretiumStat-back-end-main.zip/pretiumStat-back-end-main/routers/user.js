const express = require('express');
const uC = require('./../controllers/user')

exports.initUserRouter = (db)=>{
    const userRouter = express.Router();
    let userController = uC.initUserController(db)

    userRouter.get('/',userController.loginUser);
    userRouter.post('/register',userController.registerUser);
    userRouter.get('/login',userController.loginUser);
    
    return userRouter
}

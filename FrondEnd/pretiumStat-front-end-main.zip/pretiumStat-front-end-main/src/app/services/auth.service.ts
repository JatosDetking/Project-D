import { Injectable } from '@angular/core';
import { of, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AuthAPIService } from '../api/auth-api.service';
import { GroupService } from './group.service';
import { SharedService } from './shared.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private authAPI:AuthAPIService,
    private share:SharedService,
    ) { }

  loggedId(){
    let lastLogIn = localStorage.getItem('last-log-in-time');
    if(lastLogIn&&true&&(Date.now()-(+lastLogIn!))/1000/60/60 <= 4){
      return true  // check if there is last login and if the last login was at least 4 hours ago 
    }else{
      return false
    }
  }

  getUser(){
    return localStorage.getItem('username')!
  }

  login(username:string,password:string){
    username = username.trim()
    password = password.trim()
    return this.authAPI.login(username,password).pipe(map((res:any)=>{
      if(res.successful){
        localStorage.setItem('last-log-in-time',`${Date.now()}`);
        localStorage.setItem('username',username)
      }
      return res
    }),catchError((err)=>{
      return throwError(err)
    }))
    
  }

  register(username:string,password:string){
    username = username.trim()
    password = password.trim()
    return this.authAPI.register(username,password).pipe(map((res)=>{
      console.log(res);
      return res
    }))
  }

  logout(){
    this.share.GroupService!.removeData();
    localStorage.removeItem('last-log-in-time');
  }
}

import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSpinner } from '@angular/material/progress-spinner';
import { MatSidenav } from '@angular/material/sidenav';
import { GroupsApiService } from 'src/app/api/groups-api.service';
import { CreateGroupComponent } from 'src/app/dialogs/create-group/create-group.component';
import { DeleteGroupComponent } from 'src/app/dialogs/delete-group/delete-group.component';
import { Group } from 'src/app/interfaces/group';
import { AuthService } from 'src/app/services/auth.service';
import { GroupService } from 'src/app/services/group.service';
import { MenuService } from 'src/app/services/menu.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements AfterViewInit {

  @ViewChild('sidenav') sidenav!: MatSidenav;
  reason?:string
  spinner = false;
  groups?:Group[] = undefined
  constructor(
    private menuService:MenuService,
    public authService:AuthService,
    public groupsAPI:GroupsApiService,
    public dialog: MatDialog,
    public groupService:GroupService,
  ) {
  }


  createGroup(){
    const dialogRef = this.dialog.open(CreateGroupComponent, {
      panelClass:'create-group',
      width: '300px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.getUserGroupsData()
      }
    });
  }

  loadGroup(item:Group){
    this.groupService.selectGroup(item)
    this.close('s')
  }

  getUserGroupsData(){
    this.spinner = true;
    this.groupsAPI.getCurrUserGroupsInfo().subscribe((res:Group[])=>{
      this.groups = res
      this.spinner = false;
    })
  }

  deleteGroup(group:Group){
    const dialogRef = this.dialog.open(DeleteGroupComponent, {
      panelClass:'create-group',
      width: '300px',
      data: {group},
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getUserGroupsData()
    });
  }

  ngAfterViewInit(): void {
    this.spinner = true;
    this.menuService.initSidenav(this.sidenav)
    this.close = this.menuService.close
    this.reason = this.menuService.reason
    this.sidenav.openedChange.subscribe((open_change)=>{
      if(open_change){ // drawer is opened
        this.getUserGroupsData()
      }else{
        this.groups = undefined
        this.spinner = true;
      }
    })
  }


  close!:(reason: string)=>void

}

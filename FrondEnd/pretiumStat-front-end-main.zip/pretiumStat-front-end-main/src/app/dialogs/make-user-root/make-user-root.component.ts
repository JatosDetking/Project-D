import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-user-root',
  templateUrl: './make-user-root.component.html',
  styleUrls: ['./make-user-root.component.scss']
})
export class MakeUserRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

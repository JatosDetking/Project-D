let prod = true
export const databaseURL = prod?'https://pretium-backend.plolkin.eu':'http://localhost:3000'


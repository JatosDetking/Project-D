import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { databaseURL } from './env';
@Injectable({
  providedIn: 'root'
})
export class AuthAPIService {

  constructor(
    private http : HttpClient
    ) { }

  login(username:string,password:string){
    return this.http.get(`${databaseURL}/user/login`,{
      params:new HttpParams().set('username',username).set('password',password)
    })
  }

  register(username:string,password:string){
    return this.http.post(`${databaseURL}/user/register`,
      {username,password}
    )
  }
}
